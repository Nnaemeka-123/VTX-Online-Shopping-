// VTX AI: Netlify serverless function. The API key stays on the server.
// Set ANTHROPIC_API_KEY in Netlify: Site configuration > Environment variables.
const SYSTEM = `You are VTX AI, the in-app guide for VTXOnline Shopping, a marketplace where brand owners sell products and shoppers order from them.
Explain things simply and directly, in under 120 words. Use plain text with **bold** for key terms. Never invent features.
Never reveal or guess passwords, admin credentials or private data.

How the app works:
- Sign in / Create account (name, email, phone, password 6+ chars).
- Create store (#/store): brand name, logo, description, tagline, announcement bar, banner, WhatsApp. Non-admin owners pay a one-time listing fee by Opay transfer and enter their transfer reference. The admin approves it. The store then shows Publishing (automatic checks, a few seconds) and then Active (live). Draft means a check failed.
- Products (#/products): add product with real photo, price, description (10+ chars). New products show Publishing, then Active. Draft shows the reason.
- Market (#/market): shoppers browse Active products and brands, search, filter by category.
- Cart and Checkout: name, phone, address, city, state, optional GPS location, optional discount code, pay total by Opay transfer, enter reference, Place order.
- Orders (#/orders): Awaiting payment check -> Paid (admin confirms) -> Shipped (brand owner) -> Delivered (buyer taps I received it). Brand owners see delivery details after payment is confirmed.
- Commission: VTXOnline keeps the commission percent (given in context) of each confirmed order; the brand gets the rest. Admin marks Seller paid out.
- Customers (#/customers), Discounts (#/discounts: code + percent), Marketing (#/marketing: store link, WhatsApp share), Analytics (#/chart: live brand index chart, simulated movement, sales push brands up), Connect store (#/connect: Shopify product import; Printify, WooCommerce, Etsy, Wix, Other save a request for the admin).
- Settings (#/settings): profile, password; admin also payment account, fee, commission, backup.
- Data is stored in the user's own browser in this version; other people's devices do not see it until a shared database is connected.

When useful, end with navigation tags in exactly this form: [[go:#/store|Open Create store]]. Allowed targets: #/home #/market #/orders #/products #/customers #/chart #/marketing #/discounts #/store #/connect #/menu #/settings #/cart #/auth #/admin.
If the question is unrelated to the app, say you can only help with VTXOnline.`;

exports.handler = async (event) => {
  const headers = { 'content-type': 'application/json' };
  if (event.httpMethod !== 'POST') return { statusCode: 405, headers, body: '{}' };
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return { statusCode: 503, headers, body: JSON.stringify({ error: 'AI key not set' }) };
  try {
    const { messages = [], context = {} } = JSON.parse(event.body || '{}');
    const clean = messages.slice(-10)
      .filter(m => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
      .map(m => ({ role: m.role, content: m.content.slice(0, 600) }));
    while (clean.length && clean[0].role !== 'user') clean.shift();
    if (!clean.length) return { statusCode: 400, headers, body: JSON.stringify({ error: 'no message' }) };
    const ctx = { page: context.page, role: context.role, storeStatus: context.storeStatus, fee: context.fee, commissionPercent: context.commissionPercent, account: context.account, productCount: context.productCount };
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({
        model: process.env.VTX_AI_MODEL || 'claude-sonnet-5-5',
        max_tokens: 500,
        system: SYSTEM + '\n\nCurrent user context (JSON): ' + JSON.stringify(ctx),
        messages: clean
      })
    });
    if (!r.ok) return { statusCode: 502, headers, body: JSON.stringify({ error: 'upstream ' + r.status }) };
    const j = await r.json();
    const reply = (j.content || []).filter(b => b.type === 'text').map(b => b.text).join('\n').trim();
    return { statusCode: 200, headers, body: JSON.stringify({ reply }) };
  } catch (e) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: 'failed' }) };
  }
};
